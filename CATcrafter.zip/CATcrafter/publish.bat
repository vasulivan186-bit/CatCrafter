@echo off
cd /d "%~dp0"
dotnet publish -c Release -r win-x64 --self-contained false -o publish
echo.
echo Ready: publish\CATcrafter.exe
pause
