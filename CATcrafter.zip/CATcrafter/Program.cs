using System;
using System.Collections.Concurrent;
using System.Net.Sockets;
using System.Threading;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.IO;
using System.IO.Compression;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CATcrafter
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.Run(new Game());
        }
    }

    class Ent
    {
        public float x, y, z, vx, vy, vz, delay, craftT;
        public int csig, dur;
        public byte id;
        public bool alive = true, ground;
    }

    enum St { Menu, Worlds, Multi, Play }

    class Game : Form
    {
        [DllImport("user32.dll")]
        static extern short GetAsyncKeyState(int k);

        const int H = 48, VR = 5, UNL = 9;
        int WN = 5000, CHN = 313, sizeIdx = 3, sizeSel = 3;
        static readonly int[] SZ = { 256, 1000, 2500, 5000 };
        static readonly string[] SZN = { "Крихітний 256x256", "Малий 1000x1000", "Середній 2500x2500", "Великий 5000x5000" };
        const float HW = 1.0f, MaxView = 48f, Speed = 4f;
        const byte OAK = 1, LEAVES = 2, DIRT = 3, GRASS = 4, STONE = 5, PLANKS = 6;
        const byte I_COBBLE = 10, I_HARD = 11, I_STICK = 12, I_TOTEM = 13;
        const byte T_WPICK = 20, T_SPICK = 21, T_HPICK = 22, T_WAXE = 23, T_SAXE = 24, T_HAXE = 25;
        static readonly float[] BreakTime = { 0, 10, 3, 7, 4, 30, 6 };

        // ---- state
        St st = St.Menu;
        class Chunk { public byte[] b = new byte[16 * 16 * H]; public bool mod; }
        Chunk[,] chunks;
        string seedStr = ""; int seedInt; float unlT;
        int quality = 1, RW = 480, RH = 270;
        static readonly int[] QW = { 320, 480, 640, 960 }, QH = { 180, 270, 360, 540 };
        static readonly string[] QN = { "Низька (320x180)", "Середня (480x270)", "Висока (640x360)", "Ультра (960x540)" };
        string setPath = Path.Combine(AppContext.BaseDirectory, "settings.txt");
        float px, py, pz, yaw, pitch, vy, peakY, spawnX, spawnY, spawnZ;
        bool onGround;
        int hearts = 5, sel;
        byte[] invId = new byte[8];
        int[] invN = new int[8];
        int[] invD = new int[8];
        List<Ent> ents = new List<Ent>();
        string worldPath, seedText = "", msg = "";
        float msgT, craftAcc;
        List<string> saved = new List<string>();
        static Random rnd = new Random();

        // target / breaking
        bool hasT;
        int tgx, tgy, tgz, tAxis, tStep;
        float tDist;
        int bx = -1, by, bz;
        float breakT, breakFrac;

        // ---- network
        class RP { public string name = "?"; public float x, y, z, yaw; }
        bool mp; TcpClient tcp; NetworkStream ns; int myId; float posT;
        object sendLock = new object();
        ConcurrentQueue<Action> inbox = new ConcurrentQueue<Action>();
        Dictionary<int, Dictionary<int, byte>> mpEdits = new Dictionary<int, Dictionary<int, byte>>();
        Dictionary<int, RP> others = new Dictionary<int, RP>();
        string[] mf = { "127.0.0.1:25565", "Cat", "" };
        bool swinging; float stT;
        bool chatOpen; string chatText = ""; float ignoreKeysT;
        List<(string, float)> chat = new List<(string, float)>();
        int mfi; string netMsg = "";
        int[] ptex; int pw, ph;
        List<(int, int, string)> tags = new List<(int, int, string)>();

        // ---- graphics
        int[][] tex = new int[64][];
        int[] texS = new int[64];
        Bitmap[] icons = new Bitmap[64];
        string[] names = new string[64];
        Bitmap logo, heartFull, heartEmpty;
        int[] skyTex; int skyS; float skyT;
        Bitmap frame;
        int[] buf;
        float[] depth;
        Font fBig = new Font("Segoe UI", 34, FontStyle.Bold);
        Font fMid = new Font("Segoe UI", 16);
        Font fSm = new Font("Segoe UI", 12, FontStyle.Bold);
        Font fHeart = new Font("Segoe UI Symbol", 24);
        Point mouse;

        // ---- input
        static readonly Keys[] watch = { Keys.W, Keys.A, Keys.S, Keys.D, Keys.Left, Keys.Right, Keys.Up, Keys.Down, Keys.Space, Keys.Q, Keys.E, Keys.O, Keys.Escape, Keys.G,
            Keys.D1, Keys.D2, Keys.D3, Keys.D4, Keys.D5, Keys.D6, Keys.D7, Keys.D8 };
        bool[] cur = new bool[256], prev = new bool[256];
        bool IsDown(Keys k) { return cur[(int)k]; }
        bool WasPressed(Keys k) { return cur[(int)k] && !prev[(int)k]; }

        Stopwatch sw = Stopwatch.StartNew();
        string worldsDir = Path.Combine(AppContext.BaseDirectory, "worlds");

        // ---- recipes
        List<Dictionary<byte, int>> recIn = new List<Dictionary<byte, int>>();
        List<byte> recOut = new List<byte>();
        List<int> recN = new List<int>();
        void Rec(byte o, int n, params (byte, int)[] ing)
        {
            var d = new Dictionary<byte, int>();
            foreach (var p in ing) d[p.Item1] = p.Item2;
            recIn.Add(d); recOut.Add(o); recN.Add(n);
        }

        public Game()
        {
            Text = "CATcrafter";
            ClientSize = new Size(960, 540);
            DoubleBuffered = true;
            ResizeRedraw = true;
            BackColor = Color.White;
            StartPosition = FormStartPosition.CenterScreen;
            try { if (File.Exists(setPath)) quality = Math.Clamp(int.Parse(File.ReadAllText(setPath).Trim()), 0, 3); } catch { }
            SetQuality(quality);
            SetSize(3);
            LoadTextures();
            Rec(I_STICK, 4, (PLANKS, 2));
            Rec(PLANKS, 4, (OAK, 2));
            Rec(I_TOTEM, 1, (I_HARD, 8));
            Rec(I_HARD, 1, (I_COBBLE, 8));
            Rec(T_WPICK, 1, (PLANKS, 3), (I_STICK, 2));
            Rec(T_SPICK, 1, (I_COBBLE, 3), (I_STICK, 2));
            Rec(T_HPICK, 1, (I_HARD, 3), (I_STICK, 2));
            Rec(T_WAXE, 1, (PLANKS, 2), (I_STICK, 2));
            Rec(T_SAXE, 1, (I_COBBLE, 2), (I_STICK, 2));
            Rec(T_HAXE, 1, (I_HARD, 2), (I_STICK, 2));
            var tm = new System.Windows.Forms.Timer();
            tm.Interval = 10;
            tm.Tick += Tick;
            tm.Start();
            KeyPress += KeyPressH;
            MouseMove += (s, e) => { mouse = e.Location; };
            MouseDown += MouseDownH;
            MouseWheel += (s, e) => { if (st == St.Play) sel = ((sel - Math.Sign(e.Delta)) % 8 + 8) % 8; };
            FormClosing += (s, e) => { if (st == St.Play && !mp) SaveWorld(); if (mp) NetDisconnect(""); };
        }

        void SetSize(int idx)
        {
            sizeIdx = idx; WN = SZ[idx]; CHN = (WN + 15) / 16;
            chunks = new Chunk[CHN, CHN];
        }

        void SetQuality(int q)
        {
            quality = q; RW = QW[q]; RH = QH[q];
            if (frame != null) frame.Dispose();
            frame = new Bitmap(RW, RH, PixelFormat.Format32bppRgb);
            buf = new int[RW * RH]; depth = new float[RW * RH];
            try { File.WriteAllText(setPath, q.ToString()); } catch { }
        }

        // ================= textures
        void LoadTextures()
        {
            var map = new (byte, string, string)[] {
                (OAK, "oak", "Блок дубу"), (LEAVES, "leaves", "Листва"), (DIRT, "dirt", "Земля"), (GRASS, "grass", "Трава"), (STONE, "stone", "Камінь"),
                (I_COBBLE, "cobble", "Простий камінь"), (I_TOTEM, "totem", "Тотем"), (I_HARD, "hard", "Прочний камінь"), (I_STICK, "stick", "Палиця"),
                (T_WPICK, "wpick", "Деревяна кірка"), (T_SPICK, "spick", "Камяна кірка"), (T_HPICK, "hpick", "Прочна кірка"),
                (T_WAXE, "waxe", "Деревяна сокира"), (T_SAXE, "saxe", "Камяна сокира"), (T_HAXE, "haxe", "Прочна сокира") };
            string dir = Path.Combine(AppContext.BaseDirectory, "textures");
            foreach (var m in map)
            {
                int[] t; int size = 12;
                string f = Path.Combine(dir, m.Item2 + ".png");
                if (File.Exists(f))
                {
                    using (var src = new Bitmap(f))
                    {
                        size = Math.Max(src.Width, src.Height);
                        t = new int[size * size];
                        for (int y = 0; y < size; y++)
                            for (int x = 0; x < size; x++)
                                t[y * size + x] = (x < src.Width && y < src.Height) ? src.GetPixel(x, y).ToArgb() : 0;
                    }
                }
                else
                {
                    t = new int[size * size];
                    for (int i = 0; i < t.Length; i++)
                        t[i] = (((i / size) + (i % size)) % 2 == 0) ? unchecked((int)0xFFFF00FF) : unchecked((int)0xFF000000);
                }
                tex[m.Item1] = t; texS[m.Item1] = size; names[m.Item1] = m.Item3;
            }
            // дошки: текстури не було, генеруємо
            {
                int size = 12; var p = new int[size * size];
                for (int y = 0; y < size; y++)
                    for (int x = 0; x < size; x++)
                    {
                        int d = ((x * 7 + y * 13) % 5) * 3;
                        if (y % 4 == 3) d -= 35;
                        if (((y / 4) % 2 == 0 && x == 3) || ((y / 4) % 2 == 1 && x == 9)) d -= 35;
                        p[y * size + x] = unchecked((int)0xFF000000) | ((175 + d) << 16) | ((135 + d) << 8) | (82 + d);
                    }
                tex[PLANKS] = p; texS[PLANKS] = size; names[PLANKS] = "Дошки";
            }
            for (int id = 0; id < 64; id++)
            {
                if (tex[id] == null) continue;
                int s = texS[id];
                var b = new Bitmap(s, s, PixelFormat.Format32bppArgb);
                for (int i = 0; i < s * s; i++) b.SetPixel(i % s, i / s, Color.FromArgb(tex[id][i]));
                icons[id] = b;
            }
            string hf = Path.Combine(dir, "heart.png");
            if (File.Exists(hf))
            {
                heartFull = new Bitmap(hf);
                heartEmpty = new Bitmap(heartFull.Width, heartFull.Height, PixelFormat.Format32bppArgb);
                for (int hy0 = 0; hy0 < heartFull.Height; hy0++)
                    for (int hx0 = 0; hx0 < heartFull.Width; hx0++)
                    {
                        Color hc = heartFull.GetPixel(hx0, hy0);
                        int gr = (hc.R + hc.G + hc.B) / 6;
                        heartEmpty.SetPixel(hx0, hy0, Color.FromArgb(hc.A, gr, gr, gr));
                    }
            }
            string skf = Path.Combine(dir, "sky.png");
            if (File.Exists(skf))
            {
                using (var sk = new Bitmap(skf))
                {
                    skyS = Math.Max(sk.Width, sk.Height); skyTex = new int[skyS * skyS];
                    for (int sy0 = 0; sy0 < skyS; sy0++)
                        for (int sx0 = 0; sx0 < skyS; sx0++)
                            skyTex[sy0 * skyS + sx0] = (sx0 < sk.Width && sy0 < sk.Height) ? sk.GetPixel(sx0, sy0).ToArgb() : unchecked((int)0xFF6B8FC4);
                }
            }
            string lf = Path.Combine(dir, "player.png");
            if (File.Exists(lf))
            {
                logo = new Bitmap(lf); pw = logo.Width; ph = logo.Height;
                ptex = new int[pw * ph];
                for (int py0 = 0; py0 < ph; py0++) for (int px0 = 0; px0 < pw; px0++) ptex[py0 * pw + px0] = logo.GetPixel(px0, py0).ToArgb();
            }
        }

        // ================= world
        static int SeedHash(string s) { int h = 17; foreach (char c in s) h = h * 31 + c; return h; }
        static float Hash(int x, int z, int s)
        {
            int n = x * 374761393 + z * 668265263 + s * 1442695041;
            n = (n ^ (n >> 13)) * 1274126177;
            n ^= n >> 16;
            return (n & 0xFFFF) / 65536f;
        }
        static float Noise(float x, float z, int s)
        {
            int ix = (int)MathF.Floor(x), iz = (int)MathF.Floor(z);
            float fx = x - ix, fz = z - iz;
            fx = fx * fx * (3 - 2 * fx); fz = fz * fz * (3 - 2 * fz);
            float a = Hash(ix, iz, s), b = Hash(ix + 1, iz, s), c = Hash(ix, iz + 1, s), d = Hash(ix + 1, iz + 1, s);
            float top = a + (b - a) * fx, bot = c + (d - c) * fx;
            return top + (bot - top) * fz;
        }
        int Height(int x, int z)
        {
            return 10 + (int)(Noise(x / 80f, z / 80f, seedInt) * 16f + Noise(x / 25f, z / 25f, seedInt + 1) * 7f + Noise(x / 7f, z / 7f, seedInt + 2) * 2f);
        }

        byte GetB(int x, int y, int z)
        {
            var c = chunks[x >> 4, z >> 4];
            return c == null ? (byte)0 : c.b[(y << 8) | ((z & 15) << 4) | (x & 15)];
        }
        void SetB(int x, int y, int z, byte v)
        {
            var c = chunks[x >> 4, z >> 4];
            if (mp) RecEdit(x, y, z, v);
            if (c == null) return;
            c.b[(y << 8) | ((z & 15) << 4) | (x & 15)] = v;
            if (!mp) c.mod = true;
        }
        void RecEdit(int x, int y, int z, byte v)
        {
            int k = (x >> 4) * CHN + (z >> 4);
            Dictionary<int, byte> d;
            if (!mpEdits.TryGetValue(k, out d)) { d = new Dictionary<int, byte>(); mpEdits[k] = d; }
            d[(y << 8) | ((z & 15) << 4) | (x & 15)] = v;
        }
        int TopY(int x, int z) { for (int y = H - 1; y >= 0; y--) if (GetB(x, y, z) != 0) return y; return 0; }

        void Put(Chunk c, int x0, int z0, int x, int y, int z, byte id, bool force)
        {
            int lx = x - x0, lz = z - z0;
            if (lx < 0 || lx >= 16 || lz < 0 || lz >= 16 || y < 0 || y >= H) return;
            int i = (y << 8) | (lz << 4) | lx;
            if (force || c.b[i] == 0) c.b[i] = id;
        }

        Chunk GenChunk(int cx, int cz)
        {
            var c = new Chunk(); int x0 = cx * 16, z0 = cz * 16;
            for (int lx = 0; lx < 16; lx++)
                for (int lz = 0; lz < 16; lz++)
                {
                    int h = Height(x0 + lx, z0 + lz);
                    for (int y = 0; y < h; y++) c.b[(y << 8) | (lz << 4) | lx] = (byte)(y == h - 1 ? GRASS : (y >= h - 4 ? DIRT : STONE));
                }
            for (int tx = x0 - 2; tx < x0 + 18; tx++)
                for (int tz = z0 - 2; tz < z0 + 18; tz++)
                {
                    if (tx < 0 || tz < 0 || tx >= WN || tz >= WN) continue;
                    if (Hash(tx, tz, seedInt + 77) >= 0.012f) continue;
                    int th0 = Height(tx, tz), th = 4 + (Hash(tx, tz, seedInt + 78) < 0.5f ? 0 : 1);
                    for (int i = 0; i < th; i++) Put(c, x0, z0, tx, th0 + i, tz, OAK, true);
                    for (int dy = th - 2; dy <= th + 1; dy++)
                    {
                        int rad = dy >= th ? 1 : 2;
                        for (int dx = -rad; dx <= rad; dx++)
                            for (int dz = -rad; dz <= rad; dz++)
                            {
                                if (rad == 2 && Math.Abs(dx) == 2 && Math.Abs(dz) == 2 && Hash(tx + dx * 7, tz + dz * 13 + dy, seedInt + 79) < 0.5f) continue;
                                Put(c, x0, z0, tx + dx, th0 + dy, tz + dz, LEAVES, false);
                            }
                    }
                }
            Dictionary<int, byte> ed;
            if (mp && mpEdits.TryGetValue(cx * CHN + cz, out ed)) foreach (var kv in ed) c.b[kv.Key] = kv.Value;
            return c;
        }

        void EnsureChunks()
        {
            int pcx = Math.Clamp((int)MathF.Floor(px) >> 4, 0, CHN - 1), pcz = Math.Clamp((int)MathF.Floor(pz) >> 4, 0, CHN - 1);
            for (int dx = -VR; dx <= VR; dx++)
                for (int dz = -VR; dz <= VR; dz++)
                {
                    int cx = pcx + dx, cz = pcz + dz;
                    if (cx < 0 || cz < 0 || cx >= CHN || cz >= CHN) continue;
                    if (chunks[cx, cz] == null) chunks[cx, cz] = GenChunk(cx, cz);
                }
        }

        void UnloadFar()
        {
            int pcx = Math.Clamp((int)MathF.Floor(px) >> 4, 0, CHN - 1), pcz = Math.Clamp((int)MathF.Floor(pz) >> 4, 0, CHN - 1);
            for (int cx = 0; cx < CHN; cx++)
                for (int cz = 0; cz < CHN; cz++)
                {
                    var c = chunks[cx, cz];
                    if (c != null && !c.mod && (Math.Abs(cx - pcx) > UNL || Math.Abs(cz - pcz) > UNL)) chunks[cx, cz] = null;
                }
        }

        void NewWorld(string seed)
        {
            seedStr = seed; seedInt = SeedHash(seed);
            SetSize(sizeIdx);
            int sx = WN / 2, sz = WN / 2;
            for (int i = 0; i < 300; i++)
            {
                px = sx + 0.5f; pz = sz + 0.5f; EnsureChunks();
                if (GetB(sx, TopY(sx, sz), sz) == GRASS) break;
                sx++;
            }
            spawnX = sx + 0.5f; spawnY = TopY(sx, sz) + 1; spawnZ = sz + 0.5f;
            px = spawnX; py = spawnY; pz = spawnZ; yaw = 0; pitch = 0; vy = 0; peakY = py; hearts = 5; sel = 0;
            Array.Clear(invId, 0, 8); Array.Clear(invN, 0, 8); Array.Clear(invD, 0, 8); ents.Clear();
        }

        const int Magic = 0x43415433, Magic2 = 0x43415432;

        void SaveWorld()
        {
            try
            {
                Directory.CreateDirectory(worldsDir);
                using (var fs = File.Create(worldPath))
                using (var gz = new GZipStream(fs, CompressionLevel.Fastest))
                using (var bw = new BinaryWriter(gz))
                {
                    bw.Write(Magic); bw.Write(seedStr); bw.Write(sizeIdx);
                    bw.Write(px); bw.Write(py); bw.Write(pz); bw.Write(yaw); bw.Write(pitch); bw.Write(hearts);
                    bw.Write(spawnX); bw.Write(spawnY); bw.Write(spawnZ);
                    for (int i = 0; i < 8; i++) { bw.Write(invId[i]); bw.Write(invN[i]); bw.Write(invD[i]); }
                    int cnt = 0;
                    for (int cx = 0; cx < CHN; cx++) for (int cz = 0; cz < CHN; cz++) if (chunks[cx, cz] != null && chunks[cx, cz].mod) cnt++;
                    bw.Write(cnt);
                    for (int cx = 0; cx < CHN; cx++)
                        for (int cz = 0; cz < CHN; cz++)
                            if (chunks[cx, cz] != null && chunks[cx, cz].mod) { bw.Write(cx); bw.Write(cz); bw.Write(chunks[cx, cz].b); }
                }
            }
            catch { }
        }

        void LoadWorld(string path)
        {
            try
            {
                if (File.Exists(path + ".dead")) { netMsg = "Цей світ закрито: ви загинули."; st = St.Menu; return; }
                Chunk[,] nc = null;
                using (var fs = File.OpenRead(path))
                using (var gz = new GZipStream(fs, CompressionMode.Decompress))
                using (var br = new BinaryReader(gz))
                {
                    int mg = br.ReadInt32();
                    bool v3 = mg == Magic;
                    if (!v3 && mg != Magic2) throw new Exception("format");
                    seedStr = br.ReadString(); seedInt = SeedHash(seedStr);
                    int szi = v3 ? br.ReadInt32() : 3;
                    SetSize(Math.Clamp(szi, 0, 3)); nc = chunks;
                    px = br.ReadSingle(); py = br.ReadSingle(); pz = br.ReadSingle(); yaw = br.ReadSingle(); pitch = br.ReadSingle(); hearts = br.ReadInt32();
                    spawnX = br.ReadSingle(); spawnY = br.ReadSingle(); spawnZ = br.ReadSingle();
                    for (int i = 0; i < 8; i++)
                    {
                        invId[i] = br.ReadByte(); invN[i] = br.ReadInt32(); invD[i] = v3 ? br.ReadInt32() : 0;
                        if (invId[i] >= 20 && invD[i] <= 0) invD[i] = DurMax(invId[i]);
                    }
                    int cnt = br.ReadInt32();
                    for (int i = 0; i < cnt; i++)
                    {
                        int cx = br.ReadInt32(), cz = br.ReadInt32();
                        nc[cx, cz] = new Chunk { b = br.ReadBytes(16 * 16 * H), mod = true };
                    }
                }
                chunks = nc;
                worldPath = path; ents.Clear(); vy = 0; peakY = py; sel = 0; EnsureChunks(); st = St.Play;
            }
            catch { st = St.Menu; }
        }

        void CreateWorld(string seed)
        {
            if (string.IsNullOrWhiteSpace(seed)) seed = rnd.Next(100000, 999999).ToString();
            seed = seed.Trim();
            string name = seed;
            foreach (char c in Path.GetInvalidFileNameChars()) name = name.Replace(c, '_');
            Directory.CreateDirectory(worldsDir);
            worldPath = Path.Combine(worldsDir, name + ".cw");
            if (File.Exists(worldPath)) { LoadWorld(worldPath); return; }
            sizeIdx = sizeSel;
            NewWorld(seed);
            SaveWorld();
            st = St.Play;
        }

        void RefreshSaved()
        {
            saved.Clear();
            if (Directory.Exists(worldsDir)) foreach (var f in Directory.GetFiles(worldsDir, "*.cw")) saved.Add(f);
            if (saved.Count > 5) saved.RemoveRange(5, saved.Count - 5);
        }

        // ================= physics helpers
        bool SolidC(int x, int y, int z)
        {
            if (x < 0 || x >= WN || z < 0 || z >= WN || y < 0) return true;
            if (y >= H) return false;
            var c = chunks[x >> 4, z >> 4];
            if (c == null) return true;
            return c.b[(y << 8) | ((z & 15) << 4) | (x & 15)] != 0;
        }
        bool Solid(float x, float y, float z) { return SolidC((int)MathF.Floor(x), (int)MathF.Floor(y), (int)MathF.Floor(z)); }
        bool Collides(float x, float y, float z)
        {
            int x0 = (int)MathF.Floor(x - .3f), x1 = (int)MathF.Floor(x + .3f);
            int y0 = (int)MathF.Floor(y), y1 = (int)MathF.Floor(y + 1.7f);
            int z0 = (int)MathF.Floor(z - .3f), z1 = (int)MathF.Floor(z + .3f);
            for (int a = x0; a <= x1; a++)
                for (int b = y0; b <= y1; b++)
                    for (int c = z0; c <= z1; c++)
                        if (SolidC(a, b, c)) return true;
            return false;
        }
        bool InB(int x, int y, int z) { return x >= 0 && x < WN && y >= 0 && y < H && z >= 0 && z < WN; }

        bool Cast(float ox, float oy, float oz, float dx, float dy, float dz, float maxT, out int cx, out int cy, out int cz, out int axis, out int step, out float t)
        {
            cx = (int)MathF.Floor(ox); cy = (int)MathF.Floor(oy); cz = (int)MathF.Floor(oz); axis = 0; step = 0; t = 0;
            float ix = dx != 0 ? 1f / MathF.Abs(dx) : 1e30f, iy = dy != 0 ? 1f / MathF.Abs(dy) : 1e30f, iz = dz != 0 ? 1f / MathF.Abs(dz) : 1e30f;
            int sx = dx < 0 ? -1 : 1, sy = dy < 0 ? -1 : 1, sz = dz < 0 ? -1 : 1;
            float tx = dx != 0 ? (sx > 0 ? cx + 1 - ox : ox - cx) * ix : 1e30f;
            float ty = dy != 0 ? (sy > 0 ? cy + 1 - oy : oy - cy) * iy : 1e30f;
            float tz = dz != 0 ? (sz > 0 ? cz + 1 - oz : oz - cz) * iz : 1e30f;
            while (true)
            {
                if (tx < ty && tx < tz) { t = tx; tx += ix; cx += sx; axis = 0; step = sx; }
                else if (ty < tz) { t = ty; ty += iy; cy += sy; axis = 1; step = sy; }
                else { t = tz; tz += iz; cz += sz; axis = 2; step = sz; }
                if (t > maxT || !InB(cx, cy, cz)) return false;
                if (GetB(cx, cy, cz) != 0) return true;
            }
        }

        // ================= items
        static int DurMax(byte id)
        {
            switch (id)
            {
                case T_WPICK: case T_WAXE: return 32;
                case T_SPICK: case T_SAXE: return 96;
                case T_HPICK: case T_HAXE: return 999;
            }
            return 0;
        }

        bool AddInv(byte id, int dur = 0)
        {
            int max = id >= 20 ? 1 : 16;
            for (int i = 0; i < 8; i++) if (invN[i] > 0 && invId[i] == id && invN[i] < max) { invN[i]++; return true; }
            for (int i = 0; i < 8; i++) if (invN[i] == 0) { invId[i] = id; invN[i] = 1; invD[i] = id >= 20 ? (dur > 0 ? dur : DurMax(id)) : 0; return true; }
            return false;
        }
        void SpawnEnt(byte id, float x, float y, float z, float vx, float vy, float vz, float delay, int dur = 0)
        {
            ents.Add(new Ent { id = id, x = x, y = y, z = z, vx = vx, vy = vy, vz = vz, delay = delay, dur = dur });
        }

        float Mult(byte b, byte held)
        {
            if (b == STONE)
            {
                if (held == T_WPICK) return 1.5f;
                if (held == T_SPICK) return 2f;
                if (held == T_HPICK) return 3.5f;
            }
            else if (b == OAK || b == LEAVES || b == PLANKS)
            {
                if (held == T_WAXE) return 1.5f;
                if (held == T_SAXE) return 2f;
                if (held == T_HAXE) return 3.5f;
            }
            return 1f;
        }

        void Damage(int d)
        {
            hearts -= d;
            if (hearts > 0) return;
            for (int i = 0; i < 8; i++)
                if (invN[i] > 0 && invId[i] == I_TOTEM)
                {
                    invN[i]--; hearts = 5;
                    if (py < -10) { px = spawnX; py = spawnY; pz = spawnZ; }
                    vy = 0; peakY = py;
                    msg = "Тотем врятував вас!"; msgT = 3f;
                    return;
                }
            Die();
        }

        void Die()
        {
            Array.Clear(invId, 0, 8); Array.Clear(invN, 0, 8); Array.Clear(invD, 0, 8); hearts = 5;
            if (mp)
            {
                NetSend(bw => { bw.Write((byte)5); });
                NetDisconnect("Ви загинули. Цей акаунт закрито на цьому світі.");
            }
            else
            {
                try { File.WriteAllText(worldPath + ".dead", "1"); } catch { }
                netMsg = "Ви загинули. Цей світ закрито назавжди.";
                st = St.Menu;
            }
        }

        // ================= update
        void Step(float dt)
        {
            if (mp) { Action act; while (inbox.TryDequeue(out act)) act(); if (st != St.Play) return; }
            if (WasPressed(Keys.Escape)) { if (mp) NetDisconnect(""); else SaveWorld(); st = St.Menu; return; }
            if (WasPressed(Keys.G)) { SetQuality((quality + 1) % 4); msg = "Графіка: " + QN[quality]; msgT = 1.5f; }
            EnsureChunks();
            unlT += dt; if (unlT > 2f) { unlT = 0; UnloadFar(); }
            for (int k = 0; k < 8; k++) if (WasPressed((Keys)((int)Keys.D1 + k))) sel = k;
            if (IsDown(Keys.Left)) yaw -= 1.8f * dt;
            if (IsDown(Keys.Right)) yaw += 1.8f * dt;
            if (IsDown(Keys.Up)) pitch += 1.4f * dt;
            if (IsDown(Keys.Down)) pitch -= 1.4f * dt;
            pitch = Math.Clamp(pitch, -1.45f, 1.45f);

            float sy = MathF.Sin(yaw), cy = MathF.Cos(yaw), mx = 0, mz = 0;
            if (IsDown(Keys.W)) { mx += sy; mz += cy; }
            if (IsDown(Keys.S)) { mx -= sy; mz -= cy; }
            if (IsDown(Keys.D)) { mx += cy; mz -= sy; }
            if (IsDown(Keys.A)) { mx -= cy; mz += sy; }
            float len = MathF.Sqrt(mx * mx + mz * mz);
            if (len > 0) { mx /= len; mz /= len; }
            if (IsDown(Keys.Space) && onGround) { vy = 10.5f; onGround = false; }
            vy -= 25f * dt; if (vy < -25f) vy = -25f;
            bool wasG = onGround;
            float nx = px + mx * Speed * dt; if (!Collides(nx, py, pz)) px = nx;
            float nz = pz + mz * Speed * dt; if (!Collides(px, py, nz)) pz = nz;
            float ny = py + vy * dt; onGround = false;
            if (!Collides(px, ny, pz)) py = ny;
            else { if (vy < 0) { onGround = true; py = MathF.Floor(ny) + 1f; } vy = 0; }
            if (onGround)
            {
                if (!wasG) { int dmg = (int)((peakY - py) / 3f + 0.001f); if (dmg > 0) Damage(dmg); }
                peakY = py;
            }
            else peakY = MathF.Max(peakY, py);
            if (py < -10) Damage(99);

            // ціль
            float fx = MathF.Sin(yaw) * MathF.Cos(pitch), fy = MathF.Sin(pitch), fz = MathF.Cos(yaw) * MathF.Cos(pitch);
            hasT = Cast(px, py + 1.5f, pz, fx, fy, fz, 5f, out tgx, out tgy, out tgz, out tAxis, out tStep, out tDist);
            byte held = invN[sel] > 0 ? invId[sel] : (byte)0;

            // ламання (Q)
            if (IsDown(Keys.Q) && hasT)
            {
                if (tgx != bx || tgy != by || tgz != bz) { bx = tgx; by = tgy; bz = tgz; breakT = 0; }
                byte bb = GetB(tgx, tgy, tgz);
                float need = BreakTime[bb] / Mult(bb, held);
                breakT += dt; breakFrac = breakT / need;
                if (breakT >= need)
                {
                    SetB(tgx, tgy, tgz, 0); NetBlock(tgx, tgy, tgz, 0);
                    byte drop = bb == STONE ? I_COBBLE : bb;
                    SpawnEnt(drop, tgx + .5f, tgy + .5f, tgz + .5f, (float)(rnd.NextDouble() - .5), 2f, (float)(rnd.NextDouble() - .5), 0.6f);
                    if (held >= 20)
                    {
                        invD[sel]--;
                        if (invD[sel] <= 0) { invN[sel] = 0; msg = "Інструмент зламався!"; msgT = 1.5f; }
                    }
                    breakT = 0; breakFrac = 0; bx = -1;
                }
            }
            else { breakT = 0; breakFrac = 0; bx = -1; }

            // ставлення (E)
            if (WasPressed(Keys.E) && hasT && invN[sel] > 0 && invId[sel] >= 1 && invId[sel] <= 6)
            {
                int ax = tgx, ay = tgy, az = tgz;
                if (tAxis == 0) ax -= tStep; else if (tAxis == 1) ay -= tStep; else az -= tStep;
                if (InB(ax, ay, az) && GetB(ax, ay, az) == 0)
                {
                    byte pid = invId[sel];
                    SetB(ax, ay, az, pid);
                    if (Collides(px, py, pz)) SetB(ax, ay, az, 0); else { invN[sel]--; NetBlock(ax, ay, az, pid); }
                }
            }

            // кидання (O)
            if (WasPressed(Keys.O) && invN[sel] > 0)
            {
                byte id = invId[sel]; invN[sel]--;
                SpawnEnt(id, px + sy * 0.5f, py + 1.4f, pz + cy * 0.5f, sy * 3.5f, 3f, cy * 3.5f, 1.0f, invD[sel]);
            }

            // сутності
            foreach (var e in ents) UpdEnt(e, dt);
            foreach (var e in ents)
            {
                if (e.delay > 0 || !e.alive) continue;
                float dx = e.x - px, dy = e.y - (py + 0.8f), dz = e.z - pz;
                if (dx * dx + dy * dy + dz * dz < 1.0f && AddInv(e.id, e.dur)) e.alive = false;
            }
            craftAcc += dt;
            if (craftAcc >= 0.1f) { CraftStep(craftAcc); craftAcc = 0; }
            ents.RemoveAll(q => !q.alive);
            posT += dt; stT += dt;
            if (mp && stT > 2f) { stT = 0; NetState(); }
            swinging = IsDown(Keys.Q) && hasT;
            if (mp && posT > 0.05f)
            {
                posT = 0; float qx = px, qy = py, qz = pz, qa = yaw;
                NetSend(bw => { bw.Write((byte)2); bw.Write(qx); bw.Write(qy); bw.Write(qz); bw.Write(qa); });
            }
            if (msgT > 0) msgT -= dt;
        }

        void UpdEnt(Ent e, float dt)
        {
            e.delay -= dt; e.vy -= 25f * dt; if (e.vy < -30f) e.vy = -30f;
            float nx = e.x + e.vx * dt; if (!Solid(nx, e.y, e.z)) e.x = nx; else e.vx = 0;
            float nz = e.z + e.vz * dt; if (!Solid(e.x, e.y, nz)) e.z = nz; else e.vz = 0;
            float ny = e.y + e.vy * dt;
            if (e.vy > 0 && Solid(e.x, ny + .15f, e.z)) e.vy = 0;
            else if (e.vy <= 0 && Solid(e.x, ny - .15f, e.z)) { e.y = MathF.Floor(ny - .15f) + 1.15f; e.vy = 0; e.ground = true; }
            else { e.y = ny; e.ground = false; }
            if (e.ground) { float f = MathF.Exp(-8f * dt); e.vx *= f; e.vz *= f; }
            if (Solid(e.x, e.y, e.z) && e.y < H) e.y += 1;
        }

        // крафт: купка предметів поруч, точний збіг рецепта, 1 секунда
        void CraftStep(float step)
        {
            int n = ents.Count;
            var vis = new bool[n];
            for (int i = 0; i < n; i++)
            {
                if (vis[i] || !ents[i].alive) continue;
                var cl = new List<int> { i };
                vis[i] = true;
                for (int q = 0; q < cl.Count; q++)
                    for (int j = 0; j < n; j++)
                    {
                        if (vis[j] || !ents[j].alive) continue;
                        float dx = ents[j].x - ents[cl[q]].x, dy = ents[j].y - ents[cl[q]].y, dz = ents[j].z - ents[cl[q]].z;
                        if (dx * dx + dy * dy + dz * dz < 1.6f * 1.6f) { vis[j] = true; cl.Add(j); }
                    }
                var cnt = new Dictionary<byte, int>();
                foreach (int k in cl) { cnt.TryGetValue(ents[k].id, out int c0); cnt[ents[k].id] = c0 + 1; }
                int rec = -1;
                for (int r = 0; r < recIn.Count && rec < 0; r++)
                {
                    if (recIn[r].Count != cnt.Count) continue;
                    bool ok = true;
                    foreach (var kv in recIn[r])
                    {
                        if (!cnt.TryGetValue(kv.Key, out int c1) || c1 != kv.Value) { ok = false; break; }
                    }
                    if (ok) rec = r;
                }
                if (rec < 0) { foreach (int k in cl) { ents[k].craftT = 0; ents[k].csig = 0; } continue; }
                float mn = 1e9f;
                foreach (int k in cl)
                {
                    if (ents[k].csig != cl.Count) { ents[k].csig = cl.Count; ents[k].craftT = 0; }
                    ents[k].craftT += step;
                    mn = MathF.Min(mn, ents[k].craftT);
                }
                if (mn >= 1f)
                {
                    float ccx = 0, ccy = 0, ccz = 0;
                    foreach (int k in cl) { ccx += ents[k].x; ccy += ents[k].y; ccz += ents[k].z; ents[k].alive = false; }
                    ccx /= cl.Count; ccy /= cl.Count; ccz /= cl.Count;
                    for (int o = 0; o < recN[rec]; o++)
                        SpawnEnt(recOut[rec], ccx, ccy + .3f, ccz, (float)(rnd.NextDouble() - .5) * 1.2f, 2.5f, (float)(rnd.NextDouble() - .5) * 1.2f, 1.0f, DurMax(recOut[rec]));
                }
            }
        }

        // ================= render
        int SkyPix(float dx, float dy, float dz)
        {
            float len = MathF.Sqrt(dx * dx + dy * dy + dz * dz);
            float e = dy / len;
            float k = Math.Clamp((e - 0.03f) / 0.30f, 0f, 1f);
            int cr = 90, cg = 150, cb = 225;
            if (skyTex != null && e > 0.03f)
            {
                float u = dx / dy * 0.45f + skyT * 0.004f, v = dz / dy * 0.45f;
                int tu = ((int)MathF.Floor(u * skyS) % skyS + skyS) % skyS, tv = ((int)MathF.Floor(v * skyS) % skyS + skyS) % skyS;
                int p = skyTex[tv * skyS + tu];
                cr = (p >> 16) & 255; cg = (p >> 8) & 255; cb = p & 255;
            }
            int r = (int)(185 + (cr - 185) * k), g = (int)(212 + (cg - 212) * k), b = (int)(240 + (cb - 240) * k);
            return (255 << 24) | (r << 16) | (g << 8) | b;
        }

        int SkyAt(int y, int rh)
        {
            float f = y / (float)rh;
            return (255 << 24) | ((int)(95 + 100 * f) << 16) | ((int)(160 + 60 * f) << 8) | (int)(235 + 15 * f);
        }

        void Render()
        {
            float cyw = MathF.Cos(yaw), syw = MathF.Sin(yaw), cp = MathF.Cos(pitch), sp = MathF.Sin(pitch);
            float fx = syw * cp, fy = sp, fz = cyw * cp, rx = cyw, rz = -syw, ux = -syw * sp, uy = cp, uz = -cyw * sp;
            float ox = px, oy = py + 1.5f, oz = pz;
            bool ht = hasT;
            int tx0 = tgx, ty0 = tgy, tz0 = tgz;
            int bx0 = bx, by0 = by, bz0 = bz;
            float bf = breakFrac;
            skyT = Environment.TickCount / 1000f;
            int rw = RW, rh = RH; int[] bufL = buf; float[] depL = depth;
            Parallel.For(0, rh, y =>
            {
                float svy = (1f - 2f * (y + .5f) / rh) * HW * rh / rw;
                for (int x = 0; x < rw; x++)
                {
                    float sxv = (2f * (x + .5f) / rw - 1f) * HW;
                    float dx = fx + rx * sxv + ux * svy, dy = fy + uy * svy, dz = fz + rz * sxv + uz * svy;
                    int col = 0; bool hit = false; float dep = 1e9f;
                    int cx = (int)MathF.Floor(ox), cyy = (int)MathF.Floor(oy), cz = (int)MathF.Floor(oz);
                    float ix = dx != 0 ? 1f / MathF.Abs(dx) : 1e30f, iy = dy != 0 ? 1f / MathF.Abs(dy) : 1e30f, iz = dz != 0 ? 1f / MathF.Abs(dz) : 1e30f;
                    int stx = dx < 0 ? -1 : 1, sty = dy < 0 ? -1 : 1, stz = dz < 0 ? -1 : 1;
                    float tx = dx != 0 ? (stx > 0 ? cx + 1 - ox : ox - cx) * ix : 1e30f;
                    float ty = dy != 0 ? (sty > 0 ? cyy + 1 - oy : oy - cyy) * iy : 1e30f;
                    float tz = dz != 0 ? (stz > 0 ? cz + 1 - oz : oz - cz) * iz : 1e30f;
                    while (true)
                    {
                        int axis; float t;
                        if (tx < ty && tx < tz) { t = tx; tx += ix; cx += stx; axis = 0; }
                        else if (ty < tz) { t = ty; ty += iy; cyy += sty; axis = 1; }
                        else { t = tz; tz += iz; cz += stz; axis = 2; }
                        if (t > MaxView || cx < 0 || cx >= WN || cz < 0 || cz >= WN || cyy < 0 || cyy >= H) break;
                        var chk = chunks[cx >> 4, cz >> 4];
                        if (chk == null) break;
                        byte b = chk.b[(cyy << 8) | ((cz & 15) << 4) | (cx & 15)];
                        if (b == 0) continue;
                        float hx = ox + dx * t - cx, hy = oy + dy * t - cyy, hz = oz + dz * t - cz, u, v, sh;
                        if (axis == 0) { u = hz; v = 1 - hy; sh = 0.8f; }
                        else if (axis == 1) { u = hx; v = hz; sh = sty > 0 ? 0.5f : 1f; }
                        else { u = hx; v = 1 - hy; sh = 0.65f; }
                        int ts = texS[b];
                        int tu = Math.Clamp((int)(u * ts), 0, ts - 1), tv = Math.Clamp((int)(v * ts), 0, ts - 1);
                        int pix = tex[b][tv * ts + tu];
                        if (((pix >> 24) & 255) < 128) continue;
                        float m = sh;
                        if (ht && cx == tx0 && cyy == ty0 && cz == tz0) m *= 1.35f;
                        if (cx == bx0 && cyy == by0 && cz == bz0) m *= (1f - 0.6f * Math.Min(1f, bf));
                        int r = Math.Min(255, (int)(((pix >> 16) & 255) * m));
                        int g = Math.Min(255, (int)(((pix >> 8) & 255) * m));
                        int bl = Math.Min(255, (int)((pix & 255) * m));
                        float fg = t / MaxView; fg = Math.Min(1f, fg * fg);
                        r = (int)(r + (185 - r) * fg); g = (int)(g + (212 - g) * fg); bl = (int)(bl + (240 - bl) * fg);
                        col = (255 << 24) | (r << 16) | (g << 8) | bl; dep = t; hit = true;
                        break;
                    }
                    if (!hit) col = SkyPix(dx, dy, dz);
                    bufL[y * rw + x] = col; depL[y * rw + x] = dep;
                }
            });

            // предмети на землі
            foreach (var e in ents)
            {
                float a = e.x - ox, b = e.y + .05f - oy, c = e.z - oz;
                float z = a * fx + b * fy + c * fz;
                if (z < 0.15f) continue;
                float sxp = (a * rx + c * rz) / z, syp = (a * ux + b * uy + c * uz) / z;
                int scx = (int)((sxp / HW + 1f) * 0.5f * rw), scy = (int)((1f - syp / (HW * rh / rw)) * 0.5f * rh);
                int size = Math.Max(2, (int)(0.4f / z / HW * rw * 0.5f));
                var t = tex[e.id]; int ts = texS[e.id];
                for (int yy = 0; yy < size; yy++)
                {
                    int Y = scy - size / 2 + yy;
                    if (Y < 0 || Y >= rh) continue;
                    for (int xx = 0; xx < size; xx++)
                    {
                        int X = scx - size / 2 + xx;
                        if (X < 0 || X >= rw) continue;
                        if (depL[Y * rw + X] <= z) continue;
                        int pix = t[(yy * ts / size) * ts + (xx * ts / size)];
                        if (((pix >> 24) & 255) < 128) continue;
                        bufL[Y * rw + X] = pix | (255 << 24);
                    }
                }
            }

            tags.Clear();
            if (mp && ptex != null)
            {
                foreach (var op in others.Values)
                {
                    float a = op.x - ox, b = op.y + 0.9f - oy, c = op.z - oz;
                    float z = a * fx + b * fy + c * fz;
                    if (z < 0.15f) continue;
                    float sxp = (a * rx + c * rz) / z, syp = (a * ux + b * uy + c * uz) / z;
                    int scx = (int)((sxp / HW + 1f) * 0.5f * rw), scy = (int)((1f - syp / (HW * rh / rw)) * 0.5f * rh);
                    int hp = Math.Max(3, (int)(0.9f * rw / (HW * z))), wp = Math.Max(2, hp * pw / ph);
                    for (int yy = 0; yy < hp; yy++)
                    {
                        int Y = scy - hp / 2 + yy;
                        if (Y < 0 || Y >= rh) continue;
                        for (int xx = 0; xx < wp; xx++)
                        {
                            int X = scx - wp / 2 + xx;
                            if (X < 0 || X >= rw) continue;
                            if (depL[Y * rw + X] <= z) continue;
                            int pix = ptex[(yy * ph / hp) * pw + (xx * pw / wp)];
                            if (((pix >> 24) & 255) < 128) continue;
                            bufL[Y * rw + X] = pix | (255 << 24);
                        }
                    }
                    tags.Add((scx, scy - hp / 2 - 2, op.name));
                }
            }

            var bd = frame.LockBits(new Rectangle(0, 0, rw, rh), ImageLockMode.WriteOnly, PixelFormat.Format32bppRgb);
            Marshal.Copy(bufL, 0, bd.Scan0, bufL.Length);
            frame.UnlockBits(bd);
        }

        // ================= network
        void NetSend(Action<BinaryWriter> f)
        {
            if (!mp) return;
            try
            {
                var ms = new MemoryStream(); var bw = new BinaryWriter(ms);
                f(bw); bw.Flush();
                var d = ms.ToArray();
                lock (sendLock) { ns.Write(d, 0, d.Length); }
            }
            catch { }
        }
        void NetState()
        {
            byte[] ii = (byte[])invId.Clone(); int[] nn = (int[])invN.Clone(); int[] dd = (int[])invD.Clone(); int hh = hearts; float qx = px, qy = py, qz = pz;
            NetSend(bw =>
            {
                bw.Write((byte)4);
                for (int i = 0; i < 8; i++) { bw.Write(ii[i]); bw.Write(nn[i]); bw.Write(dd[i]); }
                bw.Write(hh); bw.Write(qx); bw.Write(qy); bw.Write(qz);
            });
        }
        void NetBlock(int x, int y, int z, byte id)
        {
            NetSend(bw => { bw.Write((byte)3); bw.Write(x); bw.Write(y); bw.Write(z); bw.Write(id); });
        }

        void NetDisconnect(string why)
        {
            if (mp && why == "") NetState();
            mp = false; chatOpen = false; chat.Clear();
            try { if (tcp != null) tcp.Close(); } catch { }
            tcp = null; ns = null;
            others.Clear(); mpEdits = new Dictionary<int, Dictionary<int, byte>>();
            netMsg = why;
            if (why != "") st = St.Multi;
        }

        bool NetConnect(string addr, string name, string pass)
        {
            try
            {
                string host = addr; int port = 25565;
                int ci = addr.LastIndexOf(':');
                if (ci > 0) { host = addr.Substring(0, ci); port = int.Parse(addr.Substring(ci + 1)); }
                var cl = new TcpClient(); cl.NoDelay = true;
                if (!cl.ConnectAsync(host, port).Wait(4000)) { cl.Close(); netMsg = "Сервер не відповідає"; return false; }
                var stream = cl.GetStream(); stream.ReadTimeout = 8000;
                var ms = new MemoryStream(); var tw = new BinaryWriter(ms);
                tw.Write((byte)1); tw.Write(name); tw.Write(pass); tw.Flush();
                var hb = ms.ToArray(); stream.Write(hb, 0, hb.Length);
                var br = new BinaryReader(stream);
                byte rt0 = br.ReadByte();
                if (rt0 == 9) throw new Exception(br.ReadString());
                if (rt0 != 10) throw new Exception("протокол");
                string seed = br.ReadString(); int szi = Math.Clamp(br.ReadInt32(), 0, 3); int id = br.ReadInt32(); int n = br.ReadInt32();
                int lim = SZ[szi], chn = (lim + 15) / 16;
                var edits = new Dictionary<int, Dictionary<int, byte>>();
                for (int i = 0; i < n; i++)
                {
                    int ex = br.ReadInt32(), ey = br.ReadInt32(), ez = br.ReadInt32(); byte eb = br.ReadByte();
                    if (ex < 0 || ex >= lim || ez < 0 || ez >= lim || ey < 0 || ey >= H) continue;
                    int k = (ex >> 4) * chn + (ez >> 4);
                    Dictionary<int, byte> d;
                    if (!edits.TryGetValue(k, out d)) { d = new Dictionary<int, byte>(); edits[k] = d; }
                    d[(ey << 8) | ((ez & 15) << 4) | (ex & 15)] = eb;
                }
                bool hs = br.ReadBoolean();
                byte[] sid = new byte[8]; int[] scn = new int[8], sdu = new int[8]; int sh = 5; float sxp0 = 0, syp0 = 0, szp0 = 0;
                if (hs)
                {
                    for (int i = 0; i < 8; i++) { sid[i] = br.ReadByte(); scn[i] = br.ReadInt32(); sdu[i] = br.ReadInt32(); }
                    sh = br.ReadInt32(); sxp0 = br.ReadSingle(); syp0 = br.ReadSingle(); szp0 = br.ReadSingle();
                }
                stream.ReadTimeout = Timeout.Infinite;
                Action dummy; while (inbox.TryDequeue(out dummy)) { }
                tcp = cl; ns = stream; myId = id; mpEdits = edits; others.Clear(); mp = true;
                sizeIdx = szi;
                NewWorld(seed);
                if (hs)
                {
                    for (int i = 0; i < 8; i++)
                    {
                        bool okI = sid[i] < 64 && tex[sid[i]] != null && scn[i] > 0;
                        invId[i] = okI ? sid[i] : (byte)0; invN[i] = okI ? Math.Min(scn[i], sid[i] >= 20 ? 1 : 16) : 0;
                        invD[i] = (okI && sid[i] >= 20) ? Math.Clamp(sdu[i] > 0 ? sdu[i] : DurMax(sid[i]), 1, 999) : 0;
                    }
                    hearts = Math.Clamp(sh, 1, 5);
                    px = sxp0; py = syp0; pz = szp0; peakY = py; vy = 0;
                }
                var rt = new Thread(() => RecvLoop(br, cl)); rt.IsBackground = true; rt.Start();
                return true;
            }
            catch (Exception ex)
            {
                mp = false; netMsg = "Помилка: " + ex.Message;
                return false;
            }
        }

        void RecvLoop(BinaryReader br, TcpClient mine)
        {
            try
            {
                while (true)
                {
                    byte t = br.ReadByte();
                    if (t == 11)
                    {
                        int id = br.ReadInt32(); string nm = br.ReadString();
                        inbox.Enqueue(() => { others[id] = new RP { name = nm }; });
                    }
                    else if (t == 12)
                    {
                        int id = br.ReadInt32(); float x = br.ReadSingle(), y = br.ReadSingle(), z = br.ReadSingle(), yw = br.ReadSingle();
                        inbox.Enqueue(() =>
                        {
                            RP r;
                            if (!others.TryGetValue(id, out r)) { r = new RP(); others[id] = r; }
                            r.x = x; r.y = y; r.z = z; r.yaw = yw;
                        });
                    }
                    else if (t == 13)
                    {
                        int id = br.ReadInt32();
                        inbox.Enqueue(() => { others.Remove(id); });
                    }
                    else if (t == 15)
                    {
                        string tx = br.ReadString();
                        inbox.Enqueue(() => { chat.Add((tx, Environment.TickCount / 1000f)); if (chat.Count > 50) chat.RemoveAt(0); });
                    }
                    else if (t == 14)
                    {
                        int x = br.ReadInt32(), y = br.ReadInt32(), z = br.ReadInt32(); byte b = br.ReadByte();
                        inbox.Enqueue(() => { if (InB(x, y, z)) SetB(x, y, z, b); });
                    }
                    else break;
                }
            }
            catch { }
            inbox.Enqueue(() => { if (tcp == mine) NetDisconnect("Зв'язок із сервером втрачено"); });
        }

        void TryJoin()
        {
            netMsg = "";
            string nm = string.IsNullOrWhiteSpace(mf[1]) ? "Cat" : mf[1].Trim();
            if (nm.Length > 16) nm = nm.Substring(0, 16);
            if (NetConnect(mf[0].Trim(), nm, mf[2])) st = St.Play;
        }

        // ================= UI layout
        Rectangle RMenu(int cw, int ch) { return new Rectangle(cw / 2 - 170, ch / 2 - 35, 340, 70); }
        Rectangle RQual(int cw, int ch) { return new Rectangle(cw / 2 - 170, ch / 2 + 135, 340, 50); }
        Rectangle RMulti(int cw, int ch) { return new Rectangle(cw / 2 - 170, ch / 2 + 50, 340, 70); }
        Rectangle RAddr(int cw) { return new Rectangle(cw / 2 - 220, 100, 440, 50); }
        Rectangle RNick(int cw) { return new Rectangle(cw / 2 - 220, 165, 440, 50); }
        Rectangle RPass(int cw) { return new Rectangle(cw / 2 - 220, 230, 440, 50); }
        Rectangle RJoin(int cw) { return new Rectangle(cw / 2 - 220, 295, 440, 50); }
        Rectangle RSeed(int cw) { return new Rectangle(cw / 2 - 220, 100, 440, 50); }
        Rectangle RSize(int cw) { return new Rectangle(cw / 2 - 220, 158, 440, 44); }
        Rectangle RCreate(int cw) { return new Rectangle(cw / 2 - 220, 210, 440, 50); }
        Rectangle RWorld(int cw, int i) { return new Rectangle(cw / 2 - 220, 305 + i * 40, 440, 34); }
        Rectangle RBack() { return new Rectangle(20, 20, 120, 40); }

        // ================= input handlers
        void KeyPressH(object s, KeyPressEventArgs e)
        {
            if (st == St.Play)
            {
                if (chatOpen)
                {
                    if (e.KeyChar == (char)8) { if (chatText.Length > 0) chatText = chatText.Substring(0, chatText.Length - 1); }
                    else if (e.KeyChar == (char)13)
                    {
                        string ct = chatText.Trim();
                        if (ct != "") NetSend(bw => { bw.Write((byte)6); bw.Write(ct); });
                        chatOpen = false; ignoreKeysT = 0.3f;
                    }
                    else if (e.KeyChar == (char)27) { chatOpen = false; ignoreKeysT = 0.3f; }
                    else if (!char.IsControl(e.KeyChar) && chatText.Length < 100) chatText += e.KeyChar;
                }
                else if (mp && (e.KeyChar == 't' || e.KeyChar == 'T' || e.KeyChar == 'е' || e.KeyChar == 'Е')) { chatOpen = true; chatText = ""; }
                return;
            }
            if (st == St.Multi)
            {
                string cur0 = mf[mfi];
                if (e.KeyChar == (char)8) { if (cur0.Length > 0) mf[mfi] = cur0.Substring(0, cur0.Length - 1); }
                else if (e.KeyChar == (char)13) TryJoin();
                else if (e.KeyChar == '\t') mfi = (mfi + 1) % 3;
                else if (!char.IsControl(e.KeyChar) && cur0.Length < 40) mf[mfi] = cur0 + e.KeyChar;
                return;
            }
            if (st != St.Worlds) return;
            if (e.KeyChar == (char)8) { if (seedText.Length > 0) seedText = seedText.Substring(0, seedText.Length - 1); }
            else if (e.KeyChar == (char)13) CreateWorld(seedText);
            else if (!char.IsControl(e.KeyChar) && seedText.Length < 24) seedText += e.KeyChar;
        }

        void MouseDownH(object s, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left) return;
            int cw = ClientSize.Width, ch = ClientSize.Height;
            if (st == St.Menu)
            {
                if (RMenu(cw, ch).Contains(e.Location)) { RefreshSaved(); seedText = ""; netMsg = ""; st = St.Worlds; }
                else if (RMulti(cw, ch).Contains(e.Location)) { netMsg = ""; st = St.Multi; }
                else if (RQual(cw, ch).Contains(e.Location)) SetQuality((quality + 1) % 4);
            }
            else if (st == St.Multi)
            {
                if (RBack().Contains(e.Location)) st = St.Menu;
                else if (RAddr(cw).Contains(e.Location)) mfi = 0;
                else if (RNick(cw).Contains(e.Location)) mfi = 1;
                else if (RPass(cw).Contains(e.Location)) mfi = 2;
                else if (RJoin(cw).Contains(e.Location)) TryJoin();
            }
            else if (st == St.Worlds)
            {
                if (RBack().Contains(e.Location)) st = St.Menu;
                else if (RSize(cw).Contains(e.Location)) sizeSel = (sizeSel + 1) % 4;
                else if (RCreate(cw).Contains(e.Location)) CreateWorld(seedText);
                else
                {
                    for (int i = 0; i < saved.Count; i++)
                        if (RWorld(cw, i).Contains(e.Location)) { LoadWorld(saved[i]); break; }
                }
            }
        }

        void Tick(object s, EventArgs ev)
        {
            float dt = (float)sw.Elapsed.TotalSeconds; sw.Restart();
            if (dt > 0.05f) dt = 0.05f;
            Array.Copy(cur, prev, 256);
            bool act = Form.ActiveForm == this;
            foreach (var k in watch) cur[(int)k] = act && (GetAsyncKeyState((int)k) & 0x8000) != 0;
            ignoreKeysT -= dt;
            if (chatOpen || ignoreKeysT > 0) Array.Clear(cur, 0, 256);
            if ((st == St.Worlds || st == St.Multi) && WasPressed(Keys.Escape)) st = St.Menu;
            if (st == St.Play)
            {
                Step(dt);
                if (st == St.Play) Render();
            }
            Invalidate();
        }

        // ================= drawing
        protected override void OnPaint(PaintEventArgs pe)
        {
            var g = pe.Graphics;
            int cw = ClientSize.Width, ch = ClientSize.Height;
            g.Clear(Color.White);
            g.TextRenderingHint = TextRenderingHint.AntiAlias;
            var sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
            if (st == St.Menu) DrawMenu(g, cw, ch, sf);
            else if (st == St.Worlds) DrawWorlds(g, cw, ch, sf);
            else if (st == St.Multi) DrawMulti(g, cw, ch, sf);
            else DrawGame(g, cw, ch, sf);
        }

        void DrawBtn(Graphics g, Rectangle r, string text, StringFormat sf)
        {
            bool hov = r.Contains(mouse);
            using (var b = new SolidBrush(hov ? Color.FromArgb(205, 220, 245) : Color.FromArgb(232, 232, 232))) g.FillRectangle(b, r);
            g.DrawRectangle(Pens.Black, r);
            g.DrawString(text, fMid, Brushes.Black, (RectangleF)r, sf);
        }

        void DrawMenu(Graphics g, int cw, int ch, StringFormat sf)
        {
            if (logo != null)
            {
                g.InterpolationMode = InterpolationMode.NearestNeighbor; g.PixelOffsetMode = PixelOffsetMode.Half;
                g.DrawImage(logo, new Rectangle(cw / 2 - 25, ch / 2 - 200, 50, 90));
            }
            g.DrawString("CATcrafter", fBig, Brushes.Black, new RectangleF(0, ch / 2 - 110, cw, 60), sf);
            DrawBtn(g, RMenu(cw, ch), "Одиночна гра", sf);
            DrawBtn(g, RMulti(cw, ch), "Мультиплеєр", sf);
            DrawBtn(g, RQual(cw, ch), "Графіка: " + QN[quality], sf);
            if (netMsg != "") g.DrawString(netMsg, fSm, Brushes.Red, new RectangleF(0, ch - 50, cw, 30), sf);
        }

        void DrawWorlds(Graphics g, int cw, int ch, StringFormat sf)
        {
            DrawBtn(g, RBack(), "Назад", sf);
            g.DrawString("Одиночна гра", fBig, Brushes.Black, new RectangleF(0, 20, cw, 70), sf);
            var rs = RSeed(cw);
            g.FillRectangle(Brushes.White, rs); g.DrawRectangle(Pens.Black, rs);
            bool blink = (Environment.TickCount / 500) % 2 == 0;
            if (seedText.Length == 0 && !blink) g.DrawString("Введіть сид світу (можна пустий)", fMid, Brushes.Gray, (RectangleF)rs, sf);
            else g.DrawString(seedText + (blink ? "|" : ""), fMid, Brushes.Black, (RectangleF)rs, sf);
            DrawBtn(g, RSize(cw), "Розмір світу: " + SZN[sizeSel], sf);
            DrawBtn(g, RCreate(cw), "Створити світ", sf);
            g.DrawString("Збережені світи:", fMid, Brushes.Black, new RectangleF(0, 268, cw, 34), sf);
            for (int i = 0; i < saved.Count; i++)
                DrawBtn(g, RWorld(cw, i), (File.Exists(saved[i] + ".dead") ? "[закрито] " : "") + Path.GetFileNameWithoutExtension(saved[i]), sf);
        }

        void DrawField(Graphics g, Rectangle r, string label, string val, bool active, StringFormat sf, bool mask = false)
        {
            g.FillRectangle(Brushes.White, r);
            using (var pen = new Pen(active ? Color.RoyalBlue : Color.Black, active ? 3 : 1)) g.DrawRectangle(pen, r);
            bool blink = (Environment.TickCount / 500) % 2 == 0;
            g.DrawString(label + ": " + (mask ? new string('*', val.Length) : val) + (active && blink ? "|" : ""), fMid, Brushes.Black, (RectangleF)r, sf);
        }

        void DrawMulti(Graphics g, int cw, int ch, StringFormat sf)
        {
            DrawBtn(g, RBack(), "Назад", sf);
            g.DrawString("Мультиплеєр", fBig, Brushes.Black, new RectangleF(0, 20, cw, 70), sf);
            DrawField(g, RAddr(cw), "Сервер (IP:порт)", mf[0], mfi == 0, sf);
            DrawField(g, RNick(cw), "Ім'я акаунта", mf[1], mfi == 1, sf);
            DrawField(g, RPass(cw), "Пароль", mf[2], mfi == 2, sf, true);
            DrawBtn(g, RJoin(cw), "Підключитись", sf);
            if (netMsg != "") g.DrawString(netMsg, fMid, Brushes.Red, new RectangleF(0, 360, cw, 40), sf);
        }

        void DrawGame(Graphics g, int cw, int ch, StringFormat sf)
        {
            g.InterpolationMode = InterpolationMode.NearestNeighbor; g.PixelOffsetMode = PixelOffsetMode.Half;
            g.DrawImage(frame, 0, 0, cw, ch);

            // приціл
            int mx = cw / 2, my = ch / 2;
            g.DrawLine(Pens.White, mx - 8, my, mx + 8, my); g.DrawLine(Pens.White, mx, my - 8, mx, my + 8);
            if (breakFrac > 0)
            {
                g.FillRectangle(Brushes.Black, mx - 32, my + 22, 64, 8);
                g.FillRectangle(Brushes.LimeGreen, mx - 31, my + 23, (int)(62 * Math.Min(1f, breakFrac)), 6);
            }

            if (invN[sel] > 0 && icons[invId[sel]] != null)
            {
                float tsec = Environment.TickCount / 1000f;
                float hsz = ch * 0.5f;
                float hang = swinging ? -15f - 55f * (0.5f + 0.5f * (float)Math.Sin(tsec * 11f)) : -12f + 3f * (float)Math.Sin(tsec * 1.5f);
                var oldT = g.Transform;
                g.TranslateTransform(cw - 40, ch + 10);
                g.RotateTransform(hang);
                g.DrawImage(icons[invId[sel]], new RectangleF(-hsz * 0.85f, -hsz * 0.95f, hsz, hsz));
                g.Transform = oldT;
            }

            // хотбар
            int slot = 56, gap = 6, total = 8 * slot + 7 * gap;
            int x0 = (cw - total) / 2, y0 = ch - slot - 14;
            for (int i = 0; i < 5; i++)
            {
                if (heartFull != null) g.DrawImage(i < hearts ? heartFull : heartEmpty, new Rectangle(x0 + i * 36, y0 - 42, 32, 32));
                else g.DrawString("♥", fHeart, i < hearts ? Brushes.Red : Brushes.DimGray, x0 + i * 40, y0 - 52);
            }
            for (int i = 0; i < 8; i++)
            {
                var r = new Rectangle(x0 + i * (slot + gap), y0, slot, slot);
                using (var br = new SolidBrush(Color.FromArgb(150, 0, 0, 0))) g.FillRectangle(br, r);
                using (var pen = new Pen(i == sel ? Color.Gold : Color.White, i == sel ? 4 : 2)) g.DrawRectangle(pen, r);
                if (invN[i] > 0 && icons[invId[i]] != null)
                {
                    g.DrawImage(icons[invId[i]], new Rectangle(r.X + 8, r.Y + 8, slot - 16, slot - 16));
                    if (invN[i] > 1) g.DrawString(invN[i].ToString(), fSm, Brushes.White, r.X + 30, r.Y + 32);
                    if (invId[i] >= 20 && DurMax(invId[i]) > 0)
                    {
                        float fr = Math.Clamp(invD[i] / (float)DurMax(invId[i]), 0f, 1f);
                        g.FillRectangle(Brushes.Black, r.X + 6, r.Bottom - 10, slot - 12, 6);
                        using (var db = new SolidBrush(fr > 0.5f ? Color.LimeGreen : fr > 0.2f ? Color.Orange : Color.Red))
                            g.FillRectangle(db, r.X + 7, r.Bottom - 9, (int)((slot - 14) * fr), 4);
                    }
                }
            }
            if (invN[sel] > 0 && names[invId[sel]] != null)
                g.DrawString(names[invId[sel]], fSm, Brushes.White, new RectangleF(0, y0 - 28, cw, 24), sf);
            if (msgT > 0) g.DrawString(msg, fBig, Brushes.Red, new RectangleF(0, ch / 2 - 120, cw, 70), sf);
            if (mp)
            {
                float kx = cw / (float)RW, ky = ch / (float)RH;
                foreach (var tg in tags) g.DrawString(tg.Item3, fSm, Brushes.White, new RectangleF(tg.Item1 * kx - 80, tg.Item2 * ky - 22, 160, 22), sf);
                g.DrawString("Онлайн: " + (others.Count + 1), fSm, Brushes.White, 10, 30);
            }
            {
                float nowS = Environment.TickCount / 1000f; int shown = 0; int baseY = ch - 150;
                for (int i = chat.Count - 1; i >= 0 && shown < 8; i--)
                {
                    if (!chatOpen && nowS - chat[i].Item2 > 12f) break;
                    shown++;
                    var rr = new RectangleF(10, baseY - shown * 22, 560, 22);
                    using (var cb = new SolidBrush(Color.FromArgb(120, 0, 0, 0))) g.FillRectangle(cb, rr);
                    g.DrawString(chat[i].Item1, fSm, Brushes.White, rr.X + 4, rr.Y + 1);
                }
                if (chatOpen)
                {
                    var ri = new RectangleF(10, baseY + 4, 560, 26);
                    using (var cb = new SolidBrush(Color.FromArgb(170, 0, 0, 0))) g.FillRectangle(cb, ri);
                    g.DrawString("> " + chatText + "|", fSm, Brushes.White, ri.X + 4, ri.Y + 3);
                }
            }
            g.DrawString("Esc - зберегти і вийти   T - чат   G - графіка   X: " + (int)px + "  Z: " + (int)pz, fSm, Brushes.White, 10, 8);
        }
    }
}
