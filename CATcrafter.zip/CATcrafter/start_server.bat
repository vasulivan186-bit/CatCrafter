@echo off
chcp 65001 >nul
cd /d "%~dp0"
where dotnet >nul 2>nul || (echo Install .NET 10 SDK: https://dotnet.microsoft.com/download/dotnet/10.0 & pause & exit /b)
set /p PORT=Port [25565]: 
if "%PORT%"=="" set PORT=25565
set /p SEED=World seed [empty = last saved or random]: 
set /p SIZE=World size for NEW world: 1=256 2=1000 3=2500 4=5000 [4]: 
if "%SIZE%"=="" set SIZE=4
dotnet run -c Release --project Server -- %PORT% "%SEED%" %SIZE%
pause
