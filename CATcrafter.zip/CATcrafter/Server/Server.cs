using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Threading;

namespace CATserver
{
    class Cl
    {
        public int id;
        public string name = "?";
        public TcpClient tcp;
        public NetworkStream ns;
        public object sl = new object();
    }

    class Acct
    {
        public string name;
        public byte[] salt, hash;
        public bool hasState, dead;
        public byte[] inv = new byte[8];
        public int[] cnt = new int[8], dur = new int[8];
        public int hearts = 5;
        public float x, y, z;
    }

    static class Server
    {
        const int Magic = 0x43573033, H = 48;
        static readonly int[] SZ = { 256, 1000, 2500, 5000 };
        static int sizeIdx = 3, WN = 5000;
        static readonly object L = new object();
        static readonly List<Cl> cls = new List<Cl>();
        static readonly Dictionary<(int, int, int), byte> edits = new Dictionary<(int, int, int), byte>();
        static readonly Dictionary<string, Acct> accts = new Dictionary<string, Acct>(StringComparer.OrdinalIgnoreCase);
        static string seed = "", savePath = "";
        static bool dirty;
        static int nextId = 1;

        static byte[] HashPw(string pw, byte[] salt)
        {
            return Rfc2898DeriveBytes.Pbkdf2(pw, salt, 20000, HashAlgorithmName.SHA256, 32);
        }

        static string Clean(string s)
        {
            foreach (char c in Path.GetInvalidFileNameChars()) s = s.Replace(c, '_');
            return s;
        }

        static void Main(string[] args)
        {
            int port = 25565;
            if (args.Length > 0 && int.TryParse(args[0], out int p)) port = p;
            string argSeed = args.Length > 1 ? args[1].Trim() : "";
            int argSize = 3;
            if (args.Length > 2 && int.TryParse(args[2], out int sz2)) argSize = Math.Clamp(sz2, 1, 4) - 1;
            Directory.CreateDirectory("saves");

            if (argSeed == "")
            {
                FileInfo best = null;
                foreach (var f in new DirectoryInfo("saves").GetFiles("*.cw3"))
                    if (best == null || f.LastWriteTime > best.LastWriteTime) best = f;
                if (best != null) savePath = best.FullName;
                else argSeed = new Random().Next(100000, 999999).ToString();
            }
            if (savePath == "") savePath = Path.Combine("saves", Clean(argSeed) + ".cw3");

            sizeIdx = argSize;
            if (File.Exists(savePath))
            {
                try
                {
                    using (var br = new BinaryReader(File.OpenRead(savePath)))
                    {
                        if (br.ReadInt32() != Magic) throw new Exception("невідомий формат");
                        seed = br.ReadString();
                        sizeIdx = Math.Clamp(br.ReadInt32(), 0, 3);
                        int n = br.ReadInt32();
                        for (int i = 0; i < n; i++)
                        {
                            int x = br.ReadInt32(), y = br.ReadInt32(), z = br.ReadInt32(); byte b = br.ReadByte();
                            edits[(x, y, z)] = b;
                        }
                        int na = br.ReadInt32();
                        for (int j = 0; j < na; j++)
                        {
                            var a = new Acct();
                            a.name = br.ReadString();
                            a.salt = br.ReadBytes(16); a.hash = br.ReadBytes(32);
                            a.hasState = br.ReadBoolean(); a.dead = br.ReadBoolean();
                            for (int q = 0; q < 8; q++) { a.inv[q] = br.ReadByte(); a.cnt[q] = br.ReadInt32(); a.dur[q] = br.ReadInt32(); }
                            a.hearts = br.ReadInt32(); a.x = br.ReadSingle(); a.y = br.ReadSingle(); a.z = br.ReadSingle();
                            accts[a.name] = a;
                        }
                    }
                }
                catch (Exception ex) { Console.WriteLine("Не вдалося прочитати збереження: " + ex.Message); }
            }
            if (seed == "") seed = argSeed;
            WN = SZ[sizeIdx];
            Console.WriteLine("CATserver: порт " + port + ", сид \"" + seed + "\", розмір світу " + WN + "x" + WN +
                ", змінених блоків: " + edits.Count + ", акаунтів: " + accts.Count);
            Console.WriteLine("Ctrl+C - зберегти і вимкнути.");

            Console.CancelKeyPress += (s, e) => { Save(); };
            var saver = new Thread(() => { while (true) { Thread.Sleep(30000); Save(); } });
            saver.IsBackground = true; saver.Start();

            var lis = new TcpListener(IPAddress.Any, port);
            lis.Start();
            while (true)
            {
                var t = lis.AcceptTcpClient();
                var th = new Thread(() => Handle(t));
                th.IsBackground = true; th.Start();
            }
        }

        static void Save()
        {
            try
            {
                byte[] data;
                lock (L)
                {
                    if (!dirty && File.Exists(savePath)) return;
                    var ms = new MemoryStream(); var bw = new BinaryWriter(ms);
                    bw.Write(Magic); bw.Write(seed); bw.Write(sizeIdx); bw.Write(edits.Count);
                    foreach (var kv in edits) { bw.Write(kv.Key.Item1); bw.Write(kv.Key.Item2); bw.Write(kv.Key.Item3); bw.Write(kv.Value); }
                    bw.Write(accts.Count);
                    foreach (var a in accts.Values)
                    {
                        bw.Write(a.name); bw.Write(a.salt); bw.Write(a.hash); bw.Write(a.hasState); bw.Write(a.dead);
                        for (int q = 0; q < 8; q++) { bw.Write(a.inv[q]); bw.Write(a.cnt[q]); bw.Write(a.dur[q]); }
                        bw.Write(a.hearts); bw.Write(a.x); bw.Write(a.y); bw.Write(a.z);
                    }
                    bw.Flush(); data = ms.ToArray(); dirty = false;
                }
                File.WriteAllBytes(savePath + ".tmp", data);
                File.Move(savePath + ".tmp", savePath, true);
            }
            catch (Exception ex) { Console.WriteLine("Помилка збереження: " + ex.Message); }
        }

        static byte[] M(Action<BinaryWriter> f)
        {
            var ms = new MemoryStream(); var bw = new BinaryWriter(ms);
            f(bw); bw.Flush();
            return ms.ToArray();
        }

        static void Raw(Cl c, byte[] d)
        {
            try { lock (c.sl) { c.ns.Write(d, 0, d.Length); } } catch { }
        }

        static void Broadcast(Cl except, byte[] d)
        {
            foreach (var o in cls) if (o != except) Raw(o, d);
        }

        static void ChatAll(string text)
        {
            Console.WriteLine(text);
            Broadcast(null, M(w => { w.Write((byte)15); w.Write(text); }));
        }

        static void Handle(TcpClient t)
        {
            var c = new Cl { tcp = t };
            bool joined = false;
            Acct a = null;
            try
            {
                t.NoDelay = true; t.SendTimeout = 5000;
                c.ns = t.GetStream();
                var br = new BinaryReader(c.ns);
                if (br.ReadByte() != 1) return;
                string nm = br.ReadString().Trim();
                string pw = br.ReadString();
                if (nm.Length < 1 || nm.Length > 16 || pw.Length < 1 || pw.Length > 64)
                {
                    Raw(c, M(w => { w.Write((byte)9); w.Write("Ім'я 1-16 символів, пароль 1-64 символи"); }));
                    return;
                }
                string err = null; bool created = false;
                lock (L)
                {
                    foreach (var o in cls) if (string.Equals(o.name, nm, StringComparison.OrdinalIgnoreCase)) err = "Цей акаунт уже в грі";
                    if (err == null)
                    {
                        if (accts.TryGetValue(nm, out a))
                        {
                            if (!CryptographicOperations.FixedTimeEquals(HashPw(pw, a.salt), a.hash)) err = "Невірний пароль";
                            else if (a.dead) err = "Цей акаунт загинув - вхід закрито";
                        }
                        else
                        {
                            a = new Acct { name = nm, salt = RandomNumberGenerator.GetBytes(16) };
                            a.hash = HashPw(pw, a.salt);
                            accts[nm] = a; dirty = true; created = true;
                        }
                    }
                    if (err != null)
                    {
                        string em = err;
                        Raw(c, M(w => { w.Write((byte)9); w.Write(em); }));
                    }
                    else
                    {
                        c.name = a.name; c.id = nextId++;
                        var ms = new MemoryStream(); var bw = new BinaryWriter(ms);
                        bw.Write((byte)10); bw.Write(seed); bw.Write(sizeIdx); bw.Write(c.id); bw.Write(edits.Count);
                        foreach (var kv in edits) { bw.Write(kv.Key.Item1); bw.Write(kv.Key.Item2); bw.Write(kv.Key.Item3); bw.Write(kv.Value); }
                        bw.Write(a.hasState);
                        if (a.hasState)
                        {
                            for (int q = 0; q < 8; q++) { bw.Write(a.inv[q]); bw.Write(a.cnt[q]); bw.Write(a.dur[q]); }
                            bw.Write(a.hearts); bw.Write(a.x); bw.Write(a.y); bw.Write(a.z);
                        }
                        foreach (var o in cls) { bw.Write((byte)11); bw.Write(o.id); bw.Write(o.name); }
                        bw.Flush();
                        Raw(c, ms.ToArray());
                        cls.Add(c); joined = true;
                        int jid = c.id; string jn = c.name;
                        Broadcast(c, M(w => { w.Write((byte)11); w.Write(jid); w.Write(jn); }));
                    }
                }
                if (err != null) return;
                if (created) Console.WriteLine("Новий акаунт: " + nm);
                lock (L) ChatAll("* " + c.name + " приєднався");
                while (true)
                {
                    byte type = br.ReadByte();
                    if (type == 2)
                    {
                        float x = br.ReadSingle(), y = br.ReadSingle(), z = br.ReadSingle(), yaw = br.ReadSingle();
                        int pid = c.id;
                        var m = M(w => { w.Write((byte)12); w.Write(pid); w.Write(x); w.Write(y); w.Write(z); w.Write(yaw); });
                        lock (L) Broadcast(c, m);
                    }
                    else if (type == 3)
                    {
                        int x = br.ReadInt32(), y = br.ReadInt32(), z = br.ReadInt32(); byte b = br.ReadByte();
                        if (x < 0 || x >= WN || z < 0 || z >= WN || y < 0 || y >= H || b > 6) continue;
                        var m = M(w => { w.Write((byte)14); w.Write(x); w.Write(y); w.Write(z); w.Write(b); });
                        lock (L) { edits[(x, y, z)] = b; dirty = true; Broadcast(c, m); }
                    }
                    else if (type == 4)
                    {
                        var inv = new byte[8]; var cn = new int[8]; var du = new int[8];
                        for (int i = 0; i < 8; i++) { inv[i] = br.ReadByte(); cn[i] = br.ReadInt32(); du[i] = br.ReadInt32(); }
                        int hp = br.ReadInt32(); float sx = br.ReadSingle(), sy = br.ReadSingle(), sz = br.ReadSingle();
                        lock (L)
                        {
                            if (a.dead) continue;
                            for (int i = 0; i < 8; i++)
                            {
                                bool ok = inv[i] < 64 && cn[i] > 0 && cn[i] <= 16;
                                a.inv[i] = ok ? inv[i] : (byte)0; a.cnt[i] = ok ? cn[i] : 0;
                                a.dur[i] = ok && inv[i] >= 20 ? Math.Clamp(du[i], 1, 999) : 0;
                            }
                            a.hearts = Math.Clamp(hp, 1, 5); a.x = sx; a.y = sy; a.z = sz;
                            a.hasState = true; dirty = true;
                        }
                    }
                    else if (type == 5)
                    {
                        lock (L)
                        {
                            a.dead = true; a.hasState = false;
                            Array.Clear(a.inv, 0, 8); Array.Clear(a.cnt, 0, 8); Array.Clear(a.dur, 0, 8);
                            dirty = true;
                            ChatAll("* " + c.name + " загинув і втратив усе");
                        }
                        break;
                    }
                    else if (type == 6)
                    {
                        string txt = br.ReadString().Trim();
                        if (txt.Length == 0) continue;
                        if (txt.Length > 100) txt = txt.Substring(0, 100);
                        lock (L) ChatAll(c.name + ": " + txt);
                    }
                    else break;
                }
            }
            catch { }
            finally
            {
                if (joined)
                {
                    int lid = c.id;
                    lock (L)
                    {
                        cls.Remove(c);
                        Broadcast(null, M(w => { w.Write((byte)13); w.Write(lid); }));
                        ChatAll("* " + c.name + " вийшов. Гравців: " + cls.Count);
                    }
                }
                try { t.Close(); } catch { }
            }
        }
    }
}
