@echo off
cd /d "%~dp0"
where dotnet >nul 2>nul || (echo Install .NET 10 SDK: https://dotnet.microsoft.com/download/dotnet/10.0 & pause & exit /b)
dotnet run -c Release
pause
